from flask import Flask, request, jsonify, render_template
from azure.storage.blob import BlobServiceClient, generate_blob_sas, BlobSasPermissions
from fuzzywuzzy import process
from datetime import datetime, timedelta
import os

app = Flask(__name__)

# Configuration for Azure Blob Storage
AZURE_CONNECTION_STRING = 
CONTAINER_NAME = 'videos'

# Initialize the BlobServiceClient
try:
    blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
except Exception as e:
    raise ValueError("Failed to connect to Azure Blob Storage. Please check the connection string.") from e

# Example dictionary with questions and blob names
qa_dict = {
    "What is AI?": 'What_is_AI.mp4',
    "What is machine learning?": "What_Is_Machine_Learning.mp4",
    "What is deep learning?": "Deep_learning_.mp4",
    "What is google sheets?": 'Google sheets.mp4',
    "What is python?": "what is python.mp4",
    "What is tableau?": "What is Tableau.mp4",
    "What is Power BI?": 'What_is_Power_BI_(720p).mp4',
    "What is Generative AI?": "Generative_AI_explained.mp4"
}

def get_best_match(user_question):
    """Find the best matching question from the dictionary."""
    questions = list(qa_dict.keys())
    best_match, score = process.extractOne(user_question, questions)
    if score >= 75:  # Threshold for similarity
        return best_match
    return None

def generate_blob_sas_url(container_name, blob_name):
    """Generate a SAS URL for secure blob access."""
    sas_token = generate_blob_sas(
        account_name=blob_service_client.account_name,
        container_name=container_name,
        blob_name=blob_name,
        account_key=blob_service_client.credential.account_key,
        permission=BlobSasPermissions(read=True),
        expiry=datetime.utcnow() + timedelta(hours=1)  # SAS valid for 1 hour
    )
    blob_url = f"https://{blob_service_client.account_name}.blob.core.windows.net/{container_name}/{blob_name}?{sas_token}"
    return blob_url

@app.route('/')
def index():
    """Render the homepage."""
    return render_template('chat.html')

@app.route('/ask', methods=['POST'])
def ask_question():
    """Handle the question and return the matching video URL."""
    data = request.json
    if not data or 'question' not in data:
        return jsonify({'error': 'Invalid request data'}), 400

    user_question = data.get('question')
    best_match = get_best_match(user_question)

    if best_match:
        blob_name = qa_dict[best_match]
        try:
            # Generate the SAS URL for secure access
            video_url = generate_blob_sas_url(CONTAINER_NAME, blob_name)
            return jsonify({'video_url': video_url, 'matched_question': best_match})
        except Exception as e:
            return jsonify({'error': f"Failed to generate video URL: {str(e)}"}), 500
    else:
        return jsonify({'error': "Sorry, I don't have a video for that question."}), 404

if __name__ == '__main__':
    app.run(debug=True)
